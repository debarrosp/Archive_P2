#! /bin/bash

my_num=$1

if [ $my_num -le 4 ] && [ $my_num = 3 ]; then
	exit 1
else
	echo "hello world"
fi

echo "this is the end of the script"
