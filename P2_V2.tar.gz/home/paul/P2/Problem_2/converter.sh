#! /bin/bash
number1=$1
number2=$1

if [ $number1 -ge 100000 ]; then
	exit 1
fi

hex_key(){
	decimal="$1"
	mod=$((decimal % 16))
	echo "$mod"
}

bin_key(){
	arg="$1"
	mod2=$((arg % 2))
	echo "$mod2"
}

hex_key number1
hex_array=()
if [ $((decimal / 16)) != 0 ]; then
       echo "true"
       x=$(hex_key number1)
       hex_array+=("$x")
       echo "$hex_array[0]"
       number1=$((decimal / 16))
       echo "$number1"
       
       while [ $number1 -gt 0 ]; do
	       a=$(hex_key number1)
	       hex_array+=("$a")
	       echo "${hex_array[*]}"
	       number1=$((number1 / 16))
       done
	       
fi

echo "${hex_array[*]}"

dictionary(){
	code="$1"
	if [ $code = 10 ]; then
		code="A"
	fi
	if [ $code = 11 ]; then
                code="B"
        fi
	if [ $code = 12 ]; then
                code="C"
        fi
	if [ $code = 13 ]; then
                code="D"
        fi
	if [ $code = 14 ]; then
                code="E"
        fi
	if [ $code = 15 ]; then
                code="F"
        fi
	if [ $code = 16 ]; then
                code="10"
        fi
	if [ $code = 26 ]; then
                code="1A"
        fi
	if [ $code = 31 ]; then
                code="1F"
        fi
	if [ $code = 32 ]; then
                code="20"
        fi
	echo "$code"
}



dictionary2(){
	binum="$1"
	truth="0"

	if [ $binum = 1 ]; then
		binum="0001"
		
	fi
	if [ $binum = 2 ]; then
                binum="0010"
                
        fi
	if [ $binum = 3 ]; then
                binum="0011"
                
        fi
	if [ $binum = 4 ]; then
                binum="0100"
                
        fi
	if [ $binum = 5 ]; then
                binum="0101"
                
        fi
	if [ $binum = 6 ]; then
                binum="0110"
                
        fi
	if [ $binum = 7 ]; then
                binum="0111"
                
        fi
	if [ $binum = 8 ]; then
                binum="1000"
                
        fi
	if [ $binum = 9 ]; then
                binum="1001"
                
        fi
	if [ $binum = 10 ]; then
                binum="1010"
                
        fi
	if [ $binum = 11 ]; then
                binum="1011"
                
        fi
	if [ $binum = 12 ]; then
                binum="1100"
                
        fi
	if [ $binum = 13 ]; then
                binum="1101"
                
        fi
	if [ $binum = 14 ]; then
                binum="1110"
                
        fi
	if [ $binum = 15 ]; then
                binum="1111"
                
        fi
	if [ $binum = 16 ]; then
                binum="00010000"
                
        fi
	if [ $binum = 26 ]; then
                binum="00011010"
                
        fi
	if [ $binum = 31 ]; then
                binum="00011111"
                
        fi
	if [ $binum = 32 ]; then
                binum="00100000"
                
        fi
	echo "$binum"
}

binary_array=()
hex_array2=()
if [ $((number2 / 16)) = 0 ] || [ $number2 = 16 ] || [ $number2 = 26 ] || [ $number2 = 31 ] || [ $number2 = 32 ]; then
        echo "this is easy"
        b=$(dictionary $number2)
        hex_array2+=("$b")
        echo "Your hex is..."
        echo "${hex_array2[*]}"
        echo "Your binary is..."
        c=$(dictionary2 $number2)
        binary_array+=("$c")
        echo "${binary_array[*]}"
        exit 1
fi

if [ $((number2 / 16)) != 0 ] && [ $number2 != 16 ] && [ $number2 != 26 ] && [ $number2 != 31 ] && [ $number2 != 32 ]; then
       y=$(bin_key $number2)
       binary_array+=("$y")
       number2=$((number2 / 2))
       echo "$number2"

       while [ $number2 -gt 0 ]; do
	       echo "first line"
               d=$(bin_key $number2)
               binary_array+=("$d")
               echo "${binary_array[*]}"
               number2=$((number2 / 2))
       done

fi







dictionary ${hex_array[1]}
length=${#hex_array[*]}
Hexidec=()
for ((i=0; i<$length; i++))
do
        add=$(dictionary ${hex_array[$i]})
        Hexidec+=("$add")
done
echo "Your Hexidecimal number is..."
echo "${Hexidec[*]}" | rev
echo "your binary number..."
echo "${binary_array[*]}" | rev

echo "$truth"

