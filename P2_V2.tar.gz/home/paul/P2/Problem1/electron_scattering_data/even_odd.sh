#! /bin/bash

for file in *.bin; do 
	num=${file//[^0-9]/}
	if [ $((num%2)) -eq 0 ]
       	then
		echo "even"
		mv $file ./even
	else
		echo "odd"
		mv $file ./odd
	fi
done
