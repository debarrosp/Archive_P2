#! /bin/bash


#user args

name=$1
echo "the file name is $name "

file_remove(){
	local file_name="$1"
	find ./$(file_name) -name "electron_scattering_data" -prune -o -name "*.bin" -exec rm {} +
}

file_remove name
